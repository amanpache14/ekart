import {NgModule} from '@angular/core';
import {RouterModule , Routes} from '@angular/router';
import { CheckoutComponent } from './customer/customer-home/customer-cart/view-cart-product/checkout.component';
import { AuthorisationErrorComponent } from './shared/authorisation-error/authorisation-error.component';

const routes:Routes=[
    {path:'error',component:AuthorisationErrorComponent},
    {path:'',redirectTo:'/applicationHome/login',pathMatch:'full'},
    {path:'checkout',component:CheckoutComponent},
];

@NgModule(
    {
        declarations:[],
        imports:[
            RouterModule.forRoot(routes)
        ],
        exports:[RouterModule]
    }
)
export class AppRoutingModule{

}