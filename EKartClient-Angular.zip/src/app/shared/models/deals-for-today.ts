import { Product } from './product';
import { Seller } from './seller';

export class deals{
    dealId: number;
    product:Product; 
    dealDiscount:number;
    dealStarts:Date;
    dealEnd:Date; 
    seller:Seller;
    status:String
}
