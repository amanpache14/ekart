import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { displayDealsForTodayComponent } from './display-deals-for-today.component';

describe('DisplayDealsForTodayComponent', () => {
  let component: displayDealsForTodayComponent;
  let fixture: ComponentFixture<displayDealsForTodayComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ displayDealsForTodayComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(displayDealsForTodayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
