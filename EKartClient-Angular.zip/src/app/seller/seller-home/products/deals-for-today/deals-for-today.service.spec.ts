  
import { TestBed } from '@angular/core/testing';

import { DealsForTodayService } from './deals-for-today.service';

describe('DealsForTodayService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: DealsForTodayService = TestBed.get(DealsForTodayService);
    expect(service).toBeTruthy();
  });
});