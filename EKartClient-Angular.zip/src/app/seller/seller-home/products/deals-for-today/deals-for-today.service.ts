import { Injectable } from '@angular/core';

import { deals } from 'src/app/shared/models/deals-for-today';
import { Observable, throwError } from 'rxjs';
import { environment } from 'src/environments/environment';
import { HttpHeaders, HttpErrorResponse, HttpClient } from '@angular/common/http';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class DealsForTodayService {

  
  private headers = new HttpHeaders({ 'Content-Type': 'application/json' });

  constructor(private http: HttpClient) { }

getProductInDeals(emailId:string): Observable<deals[]> {
  const url = environment.SellerDealsForTodayAPI + "/displayDealsForToday";
  
  return this.http.post<deals[]>(url,emailId)
    .pipe(catchError(this.handleError));

}
addDeals(deal:deals):any{
  const url = environment.SellerDealsForTodayAPI + "/addNewDealToDealsForTodayCatalog";
  return this.http.post<deals[]>(url,deal, { headers: this.headers })
    .pipe(catchError(this.handleError));

}
removeProductFromDeal(deal:deals):any{
  
  const url = environment.SellerDealsForTodayAPI + "/removeProductsFromDeals";
  return this.http.post<any>(url,deal.dealId, { headers: this.headers })
    .pipe(catchError(this.handleError));

}



    
  private handleError(err: HttpErrorResponse) {
    console.log(err)
    let errMsg: string = '';
    if (err.error instanceof Error) {
      errMsg = err.error.message;
      console.log(errMsg)
    }
    else if (typeof err.error === 'string') {
      errMsg = JSON.parse(err.error).message
    }
    else {
      if (err.status == 0) {
        errMsg = "A connection to back end can not be established.";
      } else {
        errMsg = err.error.message;
      }
    }
    return throwError(errMsg);
  }
}