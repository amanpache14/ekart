import {Component} from "@angular/core"


@Component({
    selector: 'app-checkout',
    templateUrl : './checkout.component.html', 
    styleUrls : ['./checkout.component.css']
})
export class CheckoutComponent{


    //1 total amount
    // add orders to db
    //delete cart items from db
}