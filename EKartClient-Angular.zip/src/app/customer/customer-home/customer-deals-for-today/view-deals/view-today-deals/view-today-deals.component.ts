import { Component, OnInit } from '@angular/core';
import { ViewAllProductsService } from '../../../view-all-products/view-all-products.service';
import { CustomerSharedService } from '../../../customer-shared-service';
import { Router, ActivatedRoute } from '@angular/router';
import { Product } from 'src/app/shared/models/product';
import { deals } from 'src/app/shared/models/deals-for-today';

@Component({
  selector: 'app-view-today-deals',
  templateUrl: './view-today-deals.component.html',
  styleUrls: ['./view-today-deals.component.css']
})
export class ViewTodayDealsComponent implements OnInit {
  successMessage: string;
  errorMessage: string;
  productList: Product[];
  dealsProductList:deals[];
  dealsList:deals[];

  searchText: string;
  viewDeals:boolean;
  viewDetails: boolean = false;
  selectedProduct: Product;

  p:Number =1;
  count:Number =10;

  productListToDisplay: Product[] = [];
  

  constructor(private viewAllProductService: ViewAllProductsService,
    private sharedService: CustomerSharedService,
    private router: Router,
    private route: ActivatedRoute) {

  }


  ngOnInit() {
    this.newMethod();
    
  }
  newMethod(){
    this.viewAllProductService.getAllProductsInDeals()
    .subscribe(products => {
      this.dealsList=products
      this.dealsProductList =  this.dealsList
      this.viewDeals=true;
      this.errorMessage=''
      // this.viewDetails=true
      // this.productListToDisplay = this.productList;
    }
    );
     console.log(this.dealsProductList);
  }

}
