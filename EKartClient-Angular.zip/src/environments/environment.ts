


const HOSTNAME: string = "localhost";
const PORT_NUMBER: number = 3333;
const APPLICATION_NAME: string = '/EKart_Server';
//myshec259147l
//'+PORT_NUMBER+'
export const environment = {
  production: false,
  sellerAPIUrl: 'http://' + HOSTNAME + ':' + PORT_NUMBER + APPLICATION_NAME + '/SellerAPI',
  updateSellerAPI: 'http://' + HOSTNAME + ':' + PORT_NUMBER + APPLICATION_NAME + '/SellerAPI',
  updateCustomerAPI: 'http://' + HOSTNAME + ':' + PORT_NUMBER + APPLICATION_NAME + '/CustomerAPI',
  customerAPIUrl: 'http://' + HOSTNAME + ':' + PORT_NUMBER + APPLICATION_NAME + '/CustomerAPI',
  customerCartUrl: 'http://' + HOSTNAME + ':' + PORT_NUMBER + APPLICATION_NAME + '/CustomerCartAPI',
  SellerProductManagementAPI: 'http://' + HOSTNAME + ':' + PORT_NUMBER + APPLICATION_NAME + '/SellerProductAPI',
  sellerOrderAPI: 'http://' + HOSTNAME + ':' + PORT_NUMBER + APPLICATION_NAME + '/SellerOrderAPI',
  productAPIUrl: 'http://' + HOSTNAME + ':' + PORT_NUMBER + APPLICATION_NAME + '/SellerProductAPI',
  CustomerProductAPI: 'http://' + HOSTNAME + ':' + PORT_NUMBER + APPLICATION_NAME + '/CustomerProductAPI',
  // DealsForTodayAPIUrl:'http://'+ HOSTNAME + ':'+ PORT_NUMBER+APPLICATION_NAME+'/SellerDealsForTodayAPI',
  SellerDealsForTodayAPI: 'http://' + HOSTNAME + ':' + PORT_NUMBER + APPLICATION_NAME + '/SellerDealsForTodayAPI'
  // CustomerDealsForTodayAPI:'http://' + HOSTNAME + ':' + PORT_NUMBER + APPLICATION_NAME + '/'
};